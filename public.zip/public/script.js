function renderHand(containerId, hand) {
  const container = document.getElementById(containerId);
  container.innerHTML = '';
  hand.forEach(card => {
    const div = document.createElement('div');
    div.className = 'card';
    div.textContent = `${card.rank}${card.suit}`;
    container.appendChild(div);
  });
}

function render(data) {
  if (data.player) renderHand('player-hand', data.player.hand);
  if (data.dealer) renderHand('dealer-hand', data.dealer.hand);

  const resultText = document.getElementById('result-text');

  if (data.result) {
    resultText.innerHTML = `💬 ${data.result}<br>💰 Bank: $${data.bank}`;
  } else if (data.bank !== undefined) {
    resultText.innerHTML = `💰 Bank: $${data.bank}`;
  }
}

async function startGame() {
  const bet = parseInt(document.getElementById('betAmount').value);
  const res = await fetch('/start', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ bet })
  });

  const data = await res.json();

  if (data.error) {
    alert(data.error);
    return;
  }

  render(data);
}

async function hit() {
  const res = await fetch('/hit');
  const data = await res.json();
  render(data);
}

async function stand() {
  const res = await fetch('/stand');
  const data = await res.json();
  render(data);
}
